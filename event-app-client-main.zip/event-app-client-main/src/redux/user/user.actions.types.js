const userActions = {
  LOGIN_START: "LOGIN_START",
  SET_CURRENT_USER: "SET_CURRENT_USER",
};

export default userActions;
