export const demandeSearchOptions = ["intitulé", "lieu"];

export const intervenantSearchOptions = ["nom", "prenom", "email", "telephone"];

export const sponsoringSearchOptions = ["sponsor", "èvenement", "montant"];

export const bilanSearchOptions = ["èvenement"];

export const uesersSearchOptions = ["nom", "telephone", "email"];
