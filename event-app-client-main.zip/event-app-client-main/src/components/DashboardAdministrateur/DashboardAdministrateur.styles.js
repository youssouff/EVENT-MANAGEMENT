import styled from "styled-components";

export const DashboardAdministrateurContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  padding: 30px 20px;
  justify-content: space-around;
`;
