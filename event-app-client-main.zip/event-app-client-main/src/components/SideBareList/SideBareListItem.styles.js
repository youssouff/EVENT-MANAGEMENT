import styled from "styled-components";

export const SideBareListContainer = styled.div`
  width: 60%;
  height: 80%;
  margin-top: 80px;
`;
