import styled from "styled-components";

export const DetailsBilanContainer = styled.div`
  padding: 50px;
`;

export const PhotoContainer = styled.div`
  & > img {
    border-right: 10px;
  }
`;
