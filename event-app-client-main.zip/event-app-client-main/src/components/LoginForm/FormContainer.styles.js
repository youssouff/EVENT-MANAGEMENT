import style from "styled-components";
import { Form } from "antd";

export const FormContainer = style(Form)`
.ant-form {
    width: "500px ";
    display: "flex";
    flex-direction: "column";

}

`;
