import styled from "styled-components";

export const DashboardContainer = styled.div``;
