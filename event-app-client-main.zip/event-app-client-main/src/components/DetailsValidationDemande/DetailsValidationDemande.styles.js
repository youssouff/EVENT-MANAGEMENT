import styled from "styled-components";

export const DetailsValidationContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
`;
