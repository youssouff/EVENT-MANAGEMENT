import styled from "styled-components";

export const DetailsContainer = styled.div`
  width: 100%;
  height: 90vh;
  overflow-y: scroll;
  padding: 5%;
  background-color: #f8f8fb;
`;
