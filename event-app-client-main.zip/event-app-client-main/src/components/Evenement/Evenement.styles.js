import styled from "styled-components";

export const EvenementContainer = styled.div`
  display: flex;
  justify-content: flex-start;
  margin: 0 50px;
  flex-wrap: wrap;
`;
